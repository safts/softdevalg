
#ifndef LSHASSIGN_H_AJFENIGD
#define LSHASSIGN_H_AJFENIGD

#include "../LSH.h"

void BFAssign(int );

void BuidLSHAssign(LSH **,int ,int );

double LSHAssign(int, int);

void DestroyLSHAssignment();


#endif /* end of include guard: LSHASSIGN_H_AJFENIGD */
