
#ifndef LLOYDS_H_EL7PAXIN
#define LLOYDS_H_EL7PAXIN


int LloydsUpdate(double (*assign)(), int* );

#endif /* end of include guard: LLOYDS_H_EL7PAXIN */
