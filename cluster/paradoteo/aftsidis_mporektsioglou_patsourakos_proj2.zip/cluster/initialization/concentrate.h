
#ifndef CONCENTRATE_H_YN8LUIDJ
#define CONCENTRATE_H_YN8LUIDJ


void ConcentrateInit(int );


#endif /* end of include guard: CONCENTRATE_H_YN8LUIDJ */
