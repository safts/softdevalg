
#ifndef KMEDOIDPLUSPLUS_H_TNAKEZEQ
#define KMEDOIDPLUSPLUS_H_TNAKEZEQ

void KMedoidPlusPlusInit(int );


#endif /* end of include guard: KMEDOIDPLUSPLUS_H_TNAKEZEQ */
