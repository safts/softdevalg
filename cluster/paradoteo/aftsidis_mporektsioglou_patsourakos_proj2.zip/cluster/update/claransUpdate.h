#ifndef CLARANSUPDATE_H_DLFH4J75
#define CLARANSUPDATE_H_DLFH4J75


int ClaransUpdate(double (*assign)(), int*);


#endif /* end of include guard: CLARANSUPDATE_H_DLFH4J75 */
