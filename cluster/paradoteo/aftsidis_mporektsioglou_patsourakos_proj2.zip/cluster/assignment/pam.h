
#ifndef PAM_H_AYPIDBWF
#define PAM_H_AYPIDBWF

double PamAssign(int ,int);


#endif /* end of include guard: PAM_H_AYPIDBWF */
